﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_one = New System.Windows.Forms.Button()
        Me.txt_box1 = New System.Windows.Forms.TextBox()
        Me.txt_box2 = New System.Windows.Forms.TextBox()
        Me.txt_box3 = New System.Windows.Forms.TextBox()
        Me.btn_eight = New System.Windows.Forms.Button()
        Me.btn_nine = New System.Windows.Forms.Button()
        Me.btn_four = New System.Windows.Forms.Button()
        Me.btn_five = New System.Windows.Forms.Button()
        Me.btn_six = New System.Windows.Forms.Button()
        Me.btn_three = New System.Windows.Forms.Button()
        Me.btn_two = New System.Windows.Forms.Button()
        Me.btn_seven = New System.Windows.Forms.Button()
        Me.btn_add = New System.Windows.Forms.Button()
        Me.btn_total = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_one
        '
        Me.btn_one.Location = New System.Drawing.Point(30, 236)
        Me.btn_one.Name = "btn_one"
        Me.btn_one.Size = New System.Drawing.Size(43, 38)
        Me.btn_one.TabIndex = 0
        Me.btn_one.Text = "1"
        Me.btn_one.UseVisualStyleBackColor = True
        '
        'txt_box1
        '
        Me.txt_box1.Location = New System.Drawing.Point(20, 11)
        Me.txt_box1.Multiline = True
        Me.txt_box1.Name = "txt_box1"
        Me.txt_box1.Size = New System.Drawing.Size(400, 27)
        Me.txt_box1.TabIndex = 2
        '
        'txt_box2
        '
        Me.txt_box2.Location = New System.Drawing.Point(20, 44)
        Me.txt_box2.Multiline = True
        Me.txt_box2.Name = "txt_box2"
        Me.txt_box2.Size = New System.Drawing.Size(400, 27)
        Me.txt_box2.TabIndex = 3
        '
        'txt_box3
        '
        Me.txt_box3.Location = New System.Drawing.Point(20, 77)
        Me.txt_box3.Multiline = True
        Me.txt_box3.Name = "txt_box3"
        Me.txt_box3.Size = New System.Drawing.Size(400, 27)
        Me.txt_box3.TabIndex = 4
        '
        'btn_eight
        '
        Me.btn_eight.Location = New System.Drawing.Point(89, 124)
        Me.btn_eight.Name = "btn_eight"
        Me.btn_eight.Size = New System.Drawing.Size(43, 38)
        Me.btn_eight.TabIndex = 5
        Me.btn_eight.Text = "8"
        Me.btn_eight.UseVisualStyleBackColor = True
        '
        'btn_nine
        '
        Me.btn_nine.Location = New System.Drawing.Point(149, 124)
        Me.btn_nine.Name = "btn_nine"
        Me.btn_nine.Size = New System.Drawing.Size(43, 38)
        Me.btn_nine.TabIndex = 6
        Me.btn_nine.Text = "9"
        Me.btn_nine.UseVisualStyleBackColor = True
        '
        'btn_four
        '
        Me.btn_four.Location = New System.Drawing.Point(30, 179)
        Me.btn_four.Name = "btn_four"
        Me.btn_four.Size = New System.Drawing.Size(43, 38)
        Me.btn_four.TabIndex = 7
        Me.btn_four.Text = "4"
        Me.btn_four.UseVisualStyleBackColor = True
        '
        'btn_five
        '
        Me.btn_five.Location = New System.Drawing.Point(89, 179)
        Me.btn_five.Name = "btn_five"
        Me.btn_five.Size = New System.Drawing.Size(43, 38)
        Me.btn_five.TabIndex = 8
        Me.btn_five.Text = "5"
        Me.btn_five.UseVisualStyleBackColor = True
        '
        'btn_six
        '
        Me.btn_six.Location = New System.Drawing.Point(149, 179)
        Me.btn_six.Name = "btn_six"
        Me.btn_six.Size = New System.Drawing.Size(43, 38)
        Me.btn_six.TabIndex = 9
        Me.btn_six.Text = "6"
        Me.btn_six.UseVisualStyleBackColor = True
        '
        'btn_three
        '
        Me.btn_three.Location = New System.Drawing.Point(149, 236)
        Me.btn_three.Name = "btn_three"
        Me.btn_three.Size = New System.Drawing.Size(43, 38)
        Me.btn_three.TabIndex = 12
        Me.btn_three.Text = "3"
        Me.btn_three.UseVisualStyleBackColor = True
        '
        'btn_two
        '
        Me.btn_two.Location = New System.Drawing.Point(89, 236)
        Me.btn_two.Name = "btn_two"
        Me.btn_two.Size = New System.Drawing.Size(43, 38)
        Me.btn_two.TabIndex = 11
        Me.btn_two.Text = "2"
        Me.btn_two.UseVisualStyleBackColor = True
        '
        'btn_seven
        '
        Me.btn_seven.Location = New System.Drawing.Point(30, 124)
        Me.btn_seven.Name = "btn_seven"
        Me.btn_seven.Size = New System.Drawing.Size(43, 38)
        Me.btn_seven.TabIndex = 10
        Me.btn_seven.Text = "7"
        Me.btn_seven.UseVisualStyleBackColor = True
        '
        'btn_add
        '
        Me.btn_add.Location = New System.Drawing.Point(198, 213)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.Size = New System.Drawing.Size(43, 61)
        Me.btn_add.TabIndex = 13
        Me.btn_add.Text = "+"
        Me.btn_add.UseVisualStyleBackColor = True
        '
        'btn_total
        '
        Me.btn_total.Location = New System.Drawing.Point(271, 213)
        Me.btn_total.Name = "btn_total"
        Me.btn_total.Size = New System.Drawing.Size(43, 61)
        Me.btn_total.TabIndex = 14
        Me.btn_total.Text = "="
        Me.btn_total.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(458, 369)
        Me.Controls.Add(Me.btn_total)
        Me.Controls.Add(Me.btn_add)
        Me.Controls.Add(Me.btn_three)
        Me.Controls.Add(Me.btn_two)
        Me.Controls.Add(Me.btn_seven)
        Me.Controls.Add(Me.btn_six)
        Me.Controls.Add(Me.btn_five)
        Me.Controls.Add(Me.btn_four)
        Me.Controls.Add(Me.btn_nine)
        Me.Controls.Add(Me.btn_eight)
        Me.Controls.Add(Me.txt_box3)
        Me.Controls.Add(Me.txt_box2)
        Me.Controls.Add(Me.txt_box1)
        Me.Controls.Add(Me.btn_one)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_one As Button
    Friend WithEvents txt_box1 As TextBox
    Friend WithEvents txt_box2 As TextBox
    Friend WithEvents txt_box3 As TextBox
    Friend WithEvents btn_eight As Button
    Friend WithEvents btn_nine As Button
    Friend WithEvents btn_four As Button
    Friend WithEvents btn_five As Button
    Friend WithEvents btn_six As Button
    Friend WithEvents btn_three As Button
    Friend WithEvents btn_two As Button
    Friend WithEvents btn_seven As Button
    Friend WithEvents btn_add As Button
    Friend WithEvents btn_total As Button
End Class
